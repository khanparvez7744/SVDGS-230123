import { Component, OnInit } from "@angular/core";

@Component({
  selector: "app-header",
  templateUrl: "./header.component.html",
  styleUrls: ["./header.component.css"],
})
export class HeaderComponent implements OnInit {
  constructor() {}

  ngOnInit() {
    window.onscroll = function () {
      myFunction();
    };

    var navbar: any = document.getElementById("navbar");
    var adminDiv: any = document.getElementById("adminDiv");
    var sticky: any = navbar.offsetTop;

    function myFunction() {
      if (window.pageYOffset >= sticky) {
        navbar.classList.add("sticky");
        adminDiv.classList.add("pt-5");
      } else {
        navbar.classList.remove("sticky");
        adminDiv.classList.remove("pt-5");
      }
    }
  }
  clsTogRol = false;
  public toggleRol() {
    this.clsTogRol = !this.clsTogRol;
  }
  clsTogMng = false;
  public toggleMng() {
    this.clsTogMng = !this.clsTogMng;
  }
  clsTogOpe = false;
  public toggleOpe() {
    this.clsTogOpe = !this.clsTogOpe;
  }
  clsTogSet = false;
  public toggleSet() {
    this.clsTogSet = !this.clsTogSet;
  }
}
