import { Component, OnInit } from '@angular/core';
import { schedule_flight_modal } from '../schedule-flight/schedule-flight-modal';
import { userService } from '../schedule-flight/schedule-flight-service';
// import "datatables.net";
// import "datatables.net-dt";
// import "datatables.net-buttons-dt";

@Component({
  selector: 'app-reports',
  templateUrl: './reports.component.html',
  styleUrls: ['./reports.component.css']
})
export class ReportsComponent implements OnInit {

  modal = schedule_flight_modal[1000];

  constructor(public service: userService) { }

  ngOnInit() {
    // start chock report
    // var table = $('#t1').DataTable({
    //   language: {
    //     search: "",
    //     searchPlaceholder: "Search..."
    //   },
    //   dom: 'Bfrtip',
    //   buttons: {
    //     buttons: [
    //       { extend: 'csv', text: 'CSV <i class="fa fa-download"></i>', className: 'btn-sm rounded btn-warning me-1' },
    //       { extend: 'excel', text: 'Excel <i class="fa fa-download"></i>', className: 'btn-sm rounded btn-success me-1' },
    //       { extend: 'pdf', text: 'PDF <i class="fa fa-download"></i>', className: 'btn-sm rounded btn-danger' }
    //     ]
    //   }
    // });
    // end chock report
    // start flight report
    // var table2 = $('#t2').DataTable({
    //   language: {
    //     search: "",
    //     searchPlaceholder: "Search..."
    //   },
    //   dom: 'Bfrtip',
    //   buttons: {
    //     buttons: [
    //       { extend: 'csv', text: 'CSV <i class="fa fa-download"></i>', className: 'btn-sm rounded btn-warning me-1' },
    //       { extend: 'excel', text: 'Excel <i class="fa fa-download"></i>', className: 'btn-sm rounded btn-success me-1' },
    //       { extend: 'pdf', text: 'PDF <i class="fa fa-download"></i>', className: 'btn-sm rounded btn-danger' }
    //     ]
    //   }
    // });
    // end flight report
    // start event report
    // var table3 = $('#t3').DataTable({
    //   language: {
    //     search: "",
    //     searchPlaceholder: "Search..."
    //   },
    //   dom: 'Bfrtip',
    //   buttons: {
    //     buttons: [
    //       { extend: 'csv', text: 'CSV <i class="fa fa-download"></i>', className: 'btn-sm rounded btn-warning me-1' },
    //       { extend: 'excel', text: 'Excel <i class="fa fa-download"></i>', className: 'btn-sm rounded btn-success me-1' },
    //       { extend: 'pdf', text: 'PDF <i class="fa fa-download"></i>', className: 'btn-sm rounded btn-danger' }
    //     ]
    //   }
    // });
    // end event report
    // start common code for report
    $('#dwmData1, #dwmData2, #dwmData3').hide();
    $('#tblhide1, #tblhide2, #tblhide3').hide();
    $('#t1_wrapper, #t2_wrapper, #t3_wrapper').hide();
    $('#t1, #t2, #t3').hide();
    $('#rptType').change(function () {
      $('#dwmData1, #dwmData2, #dwmData3').hide();
      $('#tblhide1, #tblhide2, #tblhide3').hide();
      $('#t1, #t2, #t3').hide();
      $('#t1_wrapper, #t2_wrapper, #t3_wrapper').hide();
      $('#t' + $(this).val()).show();
      $('#t' + $(this).val() + '_wrapper').show();
      $('#tblhide' + $(this).val()).show();
      $('#dwmData' + $(this).val()).show();
    });
    // end common code for report
    this.fetchData();

  }

  fetchData() {
    this.service.getAllReportData().subscribe((data: []) => {
      console.log('data from report', data)
      data.forEach((ab: schedule_flight_modal) => {
        // console.log('aaaaa',ab)
        if (ab.chockonString == null) {
          ab.chockonString = 'N/A';
        }

        if (ab.chockOffString == null) {
          ab.chockOffString = 'N/A';
        }

      });
      this.modal = data;

    })

    // this.settingData();


  }

  settingData() {

  }

  // getnewPage(flitered:string){
  //   console.log('getnewPage',flitered)

  //   window.open("http://192.168.2.2:8088", "_blank");
  // }

  getReportData(flitered: string) {
    console.log('filtered', flitered)
    this.service.getFilteredReportData(flitered).subscribe((data: []) => {
      data.forEach((ab: schedule_flight_modal) => {
        // console.log('aaaaa',ab)
        if (ab.chockonString == null) {
          ab.chockonString = 'N/A';
        }

        if (ab.chockOffString == null) {
          ab.chockOffString = 'N/A';
        }

      });

      this.modal = data;
    })

  }


}
