import { Component, OnInit } from "@angular/core";

@Component({
  selector: "app-stand-configuration",
  templateUrl: "./stand-configuration.component.html",
  styleUrls: ["./stand-configuration.component.css"],
})
export class StandConfigurationComponent implements OnInit {
  constructor() {}

  ngOnInit() {
    jQuery(document).ready(function () {
      (<any>jQuery("#standConfigForm")).validate();
    });
    jQuery(document).ready(function () {
      (<any>jQuery("#lidarFrm")).validate();
    });
    jQuery(document).ready(function () {
      (<any>jQuery("#objectFrm")).validate();
    });
    jQuery(document).ready(function () {
      (<any>jQuery("#speedFrm")).validate();
    });
    jQuery(document).ready(function () {
      (<any>jQuery("#centerlineFrm")).validate();
    });
  }
}
