import { Component, OnInit } from "@angular/core";

@Component({
  selector: "app-update-flight",
  templateUrl: "./update-flight.component.html",
  styleUrls: ["./update-flight.component.css"],
})
export class UpdateFlightComponent implements OnInit {
  constructor() {}

  ngOnInit() {
    jQuery(document).ready(function () {
      (<any>jQuery("#updateFrm")).validate();
    });
  }
}
