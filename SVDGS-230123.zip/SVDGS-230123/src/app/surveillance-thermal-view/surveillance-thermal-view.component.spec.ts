import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SurveillanceThermalViewComponent } from './surveillance-thermal-view.component';

describe('SurveillanceThermalViewComponent', () => {
  let component: SurveillanceThermalViewComponent;
  let fixture: ComponentFixture<SurveillanceThermalViewComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SurveillanceThermalViewComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SurveillanceThermalViewComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
