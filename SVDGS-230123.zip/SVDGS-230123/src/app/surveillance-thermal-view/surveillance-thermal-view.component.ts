import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-surveillance-thermal-view',
  templateUrl: './surveillance-thermal-view.component.html',
  styleUrls: ['./surveillance-thermal-view.component.css']
})
export class SurveillanceThermalViewComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
