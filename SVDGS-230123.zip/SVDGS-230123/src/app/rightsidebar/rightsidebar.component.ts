import { Component, OnInit } from '@angular/core';

import {schedule_flight_modal} from '../schedule-flight/schedule-flight-modal';
import {userService} from '../schedule-flight/schedule-flight-service';
import { interval } from 'rxjs';

@Component({
  selector: 'app-rightsidebar',
  templateUrl: './rightsidebar.component.html',
  styleUrls: ['./rightsidebar.component.css']
})
export class RightsidebarComponent implements OnInit {
  standModal:[];
  constructor(public service :userService) {
    interval(4000).subscribe((x =>{
      this.fetchData();
      }));
   }

  ngOnInit() {
    this.fetchData();
  }
  fetchData(){
    this.service.getAllFlightStatus().subscribe((data :[])=>{
        console.log('data from mysql',data)
        this.standModal=data;
      })
      // this.modalArray=this.modal
  }

}
