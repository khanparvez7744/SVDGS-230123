export class Abcd {

    AirportCode:String;
    FlightId:String;
    FlightNo:String;
    AircraftType:String; 
    ArrivalDeparture:String;
    Stand:String;
    STAD:String;
    ETAD:String;
    ATAD:String;
    FlightQualifier:String;
    OriginDestination:String;
    AircraftRegNo:String;
    Via:String;
    CodeShareFlight:String;
}
