import { Component, OnInit, ElementRef } from '@angular/core';
import './streamedian.min'


@Component({
    selector: 'app-streamedian-player',
    templateUrl: './streamedian-player.component.html',
    styleUrls: ['./streamedian-player.component.css']
})

export class StreamedianPlayerComponent implements OnInit {
    private html5Player: HTMLVideoElement;
    private playerId: string;
    private playerOptions: any;
    private Streamedian: any;
    private player: any;
    private canplay: boolean;
    public newSource: string;
    public rateText: string;
    public rateValue: number;
    public bufferDurationText: string;
    public bufferDurationValue: number;
    public pllogs: HTMLElement;
    public plScrollText: string
    private playerLogsId: string;
    private plScrollStat: boolean;

    constructor() {
        this.rateValue = 1.0;
        this.rateText = 'Live';
        this.playerLogsId = 'playerLogs';
        this.plScrollStat = true;
        this.plScrollText = 'Scroll off';
        this.playerId = 'video';
        this.playerOptions = {
            socket: 'ws://192.168.2.2:8088/ws/',
            redirectNativeMediaErrors: true,
            bufferDuration: 30
        };
    };
    
    ngOnInit(): void {
        
        this.html5Player = <HTMLVideoElement>document.getElementById(this.playerId);
        this.pllogs = <HTMLElement>document.getElementById(this.playerLogsId);
        this.canplay = true;
        if (window['Streamedian']) {
            this.Streamedian = window['Streamedian'];
            this.player = this.Streamedian.player(this.playerId, this.playerOptions);
            this.updateBufferDuration();
        } else {
            console.error('Failed to streamedian player import');
        }
        this.html5Player.addEventListener('canplay', () => { this.canplay = true; });
        if (!!window['chrome']) {
            document.addEventListener('visibilitychange', () => {
                if (!this.canplay) {
                    return;
                }
                if (document.visibilityState === 'hidden') {
                    ;
                    this.html5Player.pause()
                } else {
                    this.html5Player.play();
                    setTimeout(() => {
                        ;
                        this.html5Player.currentTime = this.html5Player.buffered.end(0);
                    }, 3000);
                }
            });
        }
        let newConsole = (args: any, textColor: string, backColor: string): void => {
            let text = '';
            let node = document.createElement("div");
            for (let arg in args) {
                text += ' ' + args[arg];
            }
            node.appendChild(document.createTextNode(text));
            node.style.color = textColor;
            node.style.backgroundColor = backColor;

            this.pllogs.appendChild(node);
            this.autoScroll();
        }
        (function () {
            let _log = console.log;
            let _info = console.info;
            let _warning = console.warn;
            let _error = console.error;
            console.log = function (logMessage) {
                newConsole(arguments, "black", "#A9F5A9");
                _log.apply(console, arguments);
            };
            console.info = function (warnMessage) {
                newConsole(arguments, "black", "#A9F5A9");
                _info.apply(console, arguments);
            };
            console.warn = function (warnMessage) {
                newConsole(arguments, "black", "#F3F781");
                _warning.apply(console, arguments);
            };
            console.error = function (errMessage) {
                newConsole(arguments, "black", "#F5A9A9");
                _error.apply(console, arguments);
            };

        })();
    };
    cleanLog(): void {
        while (this.pllogs.firstChild) {
            this.pllogs.removeChild(this.pllogs.firstChild);
        }
    }
    autoScroll(): void {
        if (this.plScrollStat) {
            this.pllogs.scrollTop = this.pllogs.scrollHeight;
        }
        if (this.pllogs.childElementCount > 1000) {
            this.pllogs.removeChild(this.pllogs.firstChild);
        }
    }
    setScroll(state: boolean): void {
        if (state) {
            this.pllogs.scrollTop = 0;
            this.enableScroll(false);
        } else {
            this.pllogs.scrollTop = this.pllogs.scrollHeight;
            this.enableScroll(true);
        }
    }
    toogleScroll(): void {
        if (this.plScrollStat) {
            this.enableScroll(false);
        } else {
            this.enableScroll(true);
        }
    }
    enableScroll(status: boolean): void {
        if (this.plScrollStat) {
            this.plScrollStat = false;
            this.plScrollText = "Scroll on";
        } else {
            this.plScrollStat = true;
            this.plScrollText = "Scroll off";
        }
    }
    errHandler(err: any): void {
        alert(err.message);
    };
    infHandler(inf: any): void {
        let sourcesNode = document.getElementById("sourcesNode");
        let clients = inf.clients;
        sourcesNode.innerHTML = "";
        for (let client in clients) {
            clients[client].forEach((sources) => {
                let nodeButton = document.createElement("button");
                nodeButton.setAttribute('data', sources.url + ' ' + client);
                nodeButton.appendChild(document.createTextNode(sources.description));
                nodeButton.onclick = (event) => {
                    this.newSource = (event.target as HTMLElement).getAttribute('data');
                    this.setSource();
                };
                sourcesNode.appendChild(nodeButton);
            });
        }
    };
    changeRate(value: number): void {
        this.rateValue = value;
        this.html5Player.playbackRate = value;
        this.rateText = `x${value}`;
    };
    changeBufferDuration(value: number): void {
        this.player.bufferDuration = value;
        this.bufferDurationValue = value;
        this.bufferDurationText = `${value} sec.`;
    };
    updateBufferDuration(): void {
        this.bufferDurationValue = this.player.bufferDuration || this.playerOptions.bufferDuration;
        this.bufferDurationText = `${this.bufferDurationValue} sec.`;
    } 
    setLive(): void {
        this.rateValue = 1.0;
        this.rateText = 'Live';
        this.html5Player.playbackRate = 1;
        this.html5Player.currentTime = this.html5Player.buffered.end(0);
    };
    setSource(): any {
        this.player.destroy();
        this.player = null;
        this.html5Player.src = 'rtsp://admin:admin123@192.168.2.3:554/cam/realmonitor?channel=1&subtype=0';
        this.player = this.Streamedian.player(this.playerId, this.playerOptions);
        this.updateBufferDuration();
    };
}
