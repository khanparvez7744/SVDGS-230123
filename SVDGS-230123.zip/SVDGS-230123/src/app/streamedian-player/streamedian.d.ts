export = Streamedian;
declare const Streamedian: any; 