import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { StreamedianPlayerComponent } from './streamedian-player.component';

describe('StreamedianPlayerComponent', () => {
  let component: StreamedianPlayerComponent;
  let fixture: ComponentFixture<StreamedianPlayerComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [StreamedianPlayerComponent]
    })
      .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(StreamedianPlayerComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
