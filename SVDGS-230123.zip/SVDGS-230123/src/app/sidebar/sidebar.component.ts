import { Component, OnInit } from '@angular/core';
declare var window: any;
@Component({
  selector: 'app-sidebar',
  templateUrl: './sidebar.component.html',
  styleUrls: ['./sidebar.component.css']
})
export class SidebarComponent implements OnInit {
  frmModal: any;
  frmModalUpd: any;
  constructor() { }
 
  ngOnInit() {
    this.frmModal = new window.bootstrap.Modal(
      document.getElementById('schedModalCom')
    );
    this.frmModalUpd = new window.bootstrap.Modal(
      document.getElementById('updateModalCom')
    );
  }
  openFrmModal() {
    this.frmModal.show();
  }
  openFrmModalUpd() {
    this.frmModalUpd.show();
  }
}
