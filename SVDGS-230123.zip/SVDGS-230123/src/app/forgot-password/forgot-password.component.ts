import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-forgot-password',
  templateUrl: './forgot-password.component.html',
  styleUrls: ['./forgot-password.component.css']
})
export class ForgotPasswordComponent implements OnInit {

  constructor() { }

  ngOnInit() {
    // start hide show password
    const togglePassword = document.querySelector('#togglePassword');
    const password = document.querySelector('#id_password');
    togglePassword.addEventListener('click', function (e) {
      const type = password.getAttribute('type') === 'password' ? 'text' : 'password';
      password.setAttribute('type', type);
      this.classList.toggle('fa-eye-slash');
      this.classList.toggle('fa-eye');
    });
    const togglePasswordCon = document.querySelector('#togglePasswordCon');
    const passwordCon = document.querySelector('#id_passwordCon');
    togglePasswordCon.addEventListener('click', function (e) {
      const type = passwordCon.getAttribute('type') === 'password' ? 'text' : 'password';
      passwordCon.setAttribute('type', type);
      this.classList.toggle('fa-eye-slash');
      this.classList.toggle('fa-eye');
    });
    // end hide show password
    jQuery(document).ready(function () {
      (<any>jQuery('#forgotSubmit')).validate();
    });
  }

}
