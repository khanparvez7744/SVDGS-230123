import {Injectable} from '@angular/core';
import { HttpClient } from  '@angular/common/http';
import {schedule_flight_modal} from './schedule-flight-modal';
import { Observable } from 'rxjs';

import { HttpParams } from '@angular/common/http';




@Injectable({
    providedIn:'root'
})


export class userService{

    constructor(public http:HttpClient){

    }

private url = 'http://localhost:8881/api/FlightEntry/save';
private geturl = 'http://localhost:8881/api/FlightEntry/getAllFlight';
private getSingleUser='http://localhost:8881/api/FlightEntry';
private getReportData='http://localhost:8881/api/FlightEntry/getFlightCheckonData';
private activateURL='http://localhost:8881/api/FlightEntry/activateFlight';
private flightstatusUrl='http://localhost:8881/api/FlightEntry/getAllFlightStatus';
private getFilteredReportURL='http://localhost:8881/api/FlightEntry/getFlightCheckonDataFiltered';


getPosts(modal:object): Observable <object> {
    console.log("Logged in Successfully schedule flight",modal);
    return this.http.post(this.url,modal);
}



getActivateFlight(modal:object): Observable <object> {
    console.log("Activate schedule flight",modal);
    return this.http.post(this.activateURL,modal);
}


getAll(): Observable <object> {
    console.log("Logged in Successfully schedule flight",);
    return this.http.get(this.geturl);
}


getAllFlightStatus(): Observable <object> {
    console.log("Logged in Successfully flight status",);
    return this.http.get(this.flightstatusUrl);
}


getAllReportData(): Observable <object> {
    console.log("getReportData flight",);
    return this.http.get(this.getReportData);
}

getFilteredReportData(filtered:string): Observable <object> {
    console.log("getFilteredReportData flight",);
    let queryParams = new HttpParams();
    queryParams = queryParams.append("filtered",filtered);
    return this.http.get(this.getFilteredReportURL,{params:queryParams});
}


// public getUsersMultipleParams(id: number): Observable<Object> {
//     const url = 'http://localhost:8881/api/FlightEntry/getflight';
//     // let queryParams = new HttpParams();
//     // queryParams = queryParams.append("page",8);
//     // queryParams = queryParams.append("id",'8');
//     return this.http.get(url+/${id});
// }


getStudent(id: number): Observable<Object> {  
    return this.http.get(`${this.getSingleUser}/getflight/${id}`);  
  }




    // return this.http.get(this.url).subscribe(data=>{
    //     console.log('abcd from anguar', data)
    // });
}


