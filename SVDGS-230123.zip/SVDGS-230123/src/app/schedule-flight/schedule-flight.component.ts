import { Component, OnInit } from '@angular/core';
import { schedule_flight_modal } from './schedule-flight-modal';
import { userService } from './schedule-flight-service';
import { Abcd } from '../abcd'
declare var window: any;
@Component({
  selector: 'app-schedule-flight',
  templateUrl: './schedule-flight.component.html',
  styleUrls: ['./schedule-flight.component.css']
})
export class ScheduleFlightComponent implements OnInit {
  frmModal: any;
  edited: boolean = false;
  // AirportCode:String;
  // FlightId:String;
  // FlightNo:String;
  // AircraftType:String; 
  // ArrivalDeparture:String;
  // Stand:String;
  // STAD:String;
  // ETAD:String;
  // ATAD:String;
  // FlightQualifier:String;
  // OriginDestination:String;
  // AircraftRegNo:String;
  // Via:String;
  // CodeShareFlight:String;

  modal: schedule_flight_modal;

  constructor(public service: userService) { }

  ngOnInit() {
  
    jQuery(document).ready(function () {
      (<any>jQuery('#schFlightForm')).validate();
    });
  }

  formSubmit(modal: schedule_flight_modal) {
    console.log("Logged in Successfully schedule flight", modal);

    this.service.getPosts(modal).subscribe(data => {
      console.log('abcd aa gya ', data)
      this.edited = true;
    },
      error => console.log(error));


    let id = 8;
    // this.service.getStudent(id).subscribe(data=>{
    //   console.log('getsingle flight',data)
    // })



    // this.service.getAll().subscribe(data=>{
    //   console.log('data from mysql',data)
    // })

    // this.service.getUsersMultipleParams(8).subscribe(data=>{
    //   console.log('data from multiple param', data)
    // })

    //   this.service.getPosts(modal).subscribe((modak)=>{
    //       console.warn()
    // })


  }

}
