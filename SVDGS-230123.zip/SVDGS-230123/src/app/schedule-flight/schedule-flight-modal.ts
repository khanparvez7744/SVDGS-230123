export class schedule_flight_modal {

    airportCode:String;
    flightId:String;
    flightNo:String;
    aircraftType:String; 
    arrivalDeparture:String;
    stand:String;
    stad:String;
    etad:String;
    atad:String;
    flightQualifier:String;
    originDestination:String;
    aircraftRegNo:String;
    via:String;
    codeShareFlight:String;
    chockson:String;
    chockoff:String;
    flightstatus:String;
    beltno:String;
    chockonString:String;
    chockOffString:String;

}



