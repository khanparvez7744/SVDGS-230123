import { Component, OnInit } from '@angular/core';


@Component({
    selector: 'app-player-controls',
    templateUrl: './player-controls.component.html',
    styleUrls: ['./player-controls.component.css']
})

export class PlayerControlsComponent implements OnInit {
    private video: any;
    private videoControls: any;
    private playButton: any;
    private playbackIcons: any;
    private timeElapsed: any;
    private duration: any;
    private progressBar: any;
    private seek: any;
    private seekTooltip: any;
    private volumeButton: any;
    private volumeIcons: any;
    private volumeMute: any;
    private volumeLow: any;
    private volumeHigh: any;
    private volume: any;
    private playbackAnimation: any;
    private fullscreenButton: any;
    private videoContainer: any;
    private fullscreenIcons: any;
    private pipButton: any;
    private canplay: boolean;

    constructor() { }

    ngOnInit() {
        this.video = <HTMLVideoElement>document.getElementById('video');
        this.videoControls = document.getElementById('video-controls');
        this.playButton = document.getElementById('play');
        this.playbackIcons = document.querySelectorAll('.playback-icons use');
        this.timeElapsed = document.getElementById('time-elapsed');
        this.duration = document.getElementById('duration');
        this.progressBar = document.getElementById('progress-bar');
        this.seek = document.getElementById('seek');
        this.seekTooltip = document.getElementById('seek-tooltip');
        this.volumeButton = document.getElementById('volume-button');
        this.volumeIcons = document.querySelectorAll('.volume-button use');
        this.volumeMute = document.querySelector('use[href="#volume-mute"]');
        this.volumeLow = document.querySelector('use[href="#volume-low"]');
        this.volumeHigh = document.querySelector('use[href="#volume-high"]');
        this.volume = document.getElementById('volume');
        this.playbackAnimation = document.getElementById('playback-animation');
        this.fullscreenButton = document.getElementById('fullscreen-button');
        this.videoContainer = document.getElementById('video-container');
        this.fullscreenIcons = this.fullscreenButton.querySelectorAll('use');
        this.pipButton = document.getElementById('pip-button');
        this.canplay = true;
        this.playButton.addEventListener('click', this.togglePlay.bind(this));
        this.video.addEventListener('play', this.updatePlayButton.bind(this));
        this.video.addEventListener('pause', this.updatePlayButton.bind(this));
        this.video.addEventListener('loadedmetadata', this.initializeVideo.bind(this));
        this.video.addEventListener('timeupdate', this.updateTimeElapsed.bind(this));
        this.video.addEventListener('timeupdate', this.updateProgress.bind(this));
        this.video.addEventListener('volumechange', this.updateVolumeIcon.bind(this));
        this.video.addEventListener('click', this.togglePlay.bind(this));
        this.video.addEventListener('click', this.animatePlayback.bind(this));
        this.video.addEventListener('mouseenter', this.showControls.bind(this));
        this.video.addEventListener('mouseleave', this.hideControls.bind(this));
        this.videoControls.addEventListener('mouseenter', this.showControls.bind(this));
        this.videoControls.addEventListener('mouseleave', this.hideControls.bind(this));
        this.seek.addEventListener('mousemove', this.updateSeekTooltip.bind(this));
        this.seek.addEventListener('input', this.skipAhead.bind(this));
        this.volume.addEventListener('input', this.updateVolume.bind(this));
        this.volumeButton.addEventListener('click', this.toggleMute.bind(this));
        this.fullscreenButton.addEventListener('click', this.toggleFullScreen.bind(this));
        this.videoContainer.addEventListener('fullscreenchange', this.updateFullscreenButton.bind(this));
        this.pipButton.addEventListener('click', this.togglePip.bind(this));
        this.video.addEventListener('canplay', () => { this.canplay = true; });
    }

    togglePlay() {
        if (this.video.paused || this.video.ended) {
            this.video.play();
        } else {
            this.video.pause();
        }
    }

    updatePlayButton() {
        this.playbackIcons.forEach(icon => icon.classList.toggle('hidden'));

        if (this.video.paused) {
            this.playButton.setAttribute('data-title', 'Play (k)')
        } else {
            this.playButton.setAttribute('data-title', 'Pause (k)')
        }
    }

    formatTime(timeInSeconds) {
        const result = new Date(timeInSeconds * 1000).toISOString().substr(11, 8);

        return {
            minutes: result.substr(3, 2),
            seconds: result.substr(6, 2),
        };
    }

    initializeVideo() {
        const videoDuration = Math.round(this.video.duration);
        this.seek.setAttribute('max', videoDuration);
        this.progressBar.setAttribute('max', videoDuration);
        const time = this.formatTime(videoDuration);
        this.duration.innerText = `${time.minutes}:${time.seconds}`;
        this.duration.setAttribute('datetime', `${time.minutes}m ${time.seconds}s`)
    }

    updateTimeElapsed() {
        if (this.canplay) {
            const time = this.formatTime(Math.round(this.video.currentTime));
            this.timeElapsed.innerText = `${time.minutes}:${time.seconds}`;
            this.timeElapsed.setAttribute('datetime', `${time.minutes}m ${time.seconds}s`);
        }
    }

    updateProgress() {
        const startTime = Math.floor(this.video.buffered.start(0));
        const endTime = Math.floor(this.video.buffered.end(0));
        const currentTime = Math.floor(this.video.currentTime);
        const time = this.formatTime(endTime);
        this.duration.innerText = `${time.minutes}:${time.seconds}`;
        this.duration.setAttribute('datetime', `${time.minutes}m ${time.seconds}s`)
        this.seek.setAttribute('max', endTime);
        this.progressBar.setAttribute('max', endTime);
        this.seek.value = currentTime;
        this.seek.min = startTime;
        this.progressBar.value = currentTime;
        this.progressBar.min = startTime;
    }

    updateSeekTooltip(event) {
        if (this.canplay) {
            const max = parseInt(event.target.getAttribute('max'), 10);
            const min = parseInt(event.target.getAttribute('min'), 10);
            const skipTo = min + Math.round((event.offsetX / event.target.clientWidth) * (max - min));
            const time = this.formatTime(skipTo);
            const rect = this.video.getBoundingClientRect();
            this.seek.setAttribute('data-seek', skipTo)
            this.seekTooltip.textContent = `${time.minutes}:${time.seconds}`;
            this.seekTooltip.style.left = `${event.pageX - rect.left}px`;
        }
    }

    skipAhead(event) {
        const skipTo = event.target.dataset.seek ? event.target.dataset.seek : event.target.value;
        this.video.currentTime = skipTo;
        this.progressBar.value = skipTo;
        this.seek.value = skipTo;
    }

    updateVolume() {
        if (this.video.muted) {
            this.video.muted = false;
        }
        this.video.volume = this.volume.value;
    }

    updateVolumeIcon() {
        this.volumeIcons.forEach(icon => {
            icon.classList.add('hidden');
        });
        this.volumeButton.setAttribute('data-title', 'Mute (m)');
        if (this.video.muted || this.video.volume === 0) {
            this.volumeMute.classList.remove('hidden');
            this.volumeButton.setAttribute('data-title', 'Unmute (m)');
        } else if (this.video.volume > 0 && this.video.volume <= 0.5) {
            this.volumeLow.classList.remove('hidden');
        } else {
            this.volumeHigh.classList.remove('hidden');
        }
    }

    toggleMute() {
        this.video.muted = !this.video.muted;
        if (this.video.muted) {
            this.volume.setAttribute('data-volume', this.volume.value);
            this.volume.value = 0;
        } else {
            this.volume.value = this.volume.dataset.volume;
        }
    }

    animatePlayback() {
        this.playbackAnimation.animate([{
            opacity: 1,
            transform: "scale(1)",
        }, {
            opacity: 0,
            transform: "scale(1.3)",
        }], {
            duration: 500,
        });
    }

    toggleFullScreen(): void {
        if (document['fullscreenElement']) {
            document.exitFullscreen();
        } else {
            this.videoContainer.requestFullscreen();
        }
    }

    updateFullscreenButton() {
        this.fullscreenIcons.forEach(icon => icon.classList.toggle('hidden'));
        if (document['fullscreenElement']) {
            this.fullscreenButton.setAttribute('data-title', 'Exit full screen (f)');
        } else {
            this.fullscreenButton.setAttribute('data-title', 'Full screen (f)');
        }
    }

    async togglePip() {
        try {
            if (this.video !== document['pictureInPictureElement']) {
                this.pipButton.disabled = true;
                await this.video.requestPictureInPicture();
            } else {
            }
        } catch (error) {
            console.error(error)
        } finally {
            this.pipButton.disabled = false;
        }
    }

    hideControls() {
        if (this.video.paused) {
            return;
        }

        this.videoControls.classList.add('hide');
    }

    showControls() {
        this.videoControls.classList.remove('hide');
    }

    keyboardShortcuts(event) {
        const { key } = event;

        switch (key) {
            case 'k':
                this.togglePlay();
                this.animatePlayback();
                if (this.video.paused) {
                    this.showControls();
                } else {
                    setTimeout(() => {
                        this.hideControls();
                    }, 2000);
                }
                break;
            case 'm':
                this.toggleMute();
                break;
            case 'f':
                this.toggleFullScreen();
                break;
            case 'p':
                this.togglePip();
                break;
        }
    }
}
