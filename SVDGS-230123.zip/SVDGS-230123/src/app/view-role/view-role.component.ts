import { Component, OnInit } from '@angular/core';
import { DataTableDirective } from 'angular-datatables';

@Component({
  selector: 'app-view-role',
  templateUrl: './view-role.component.html',
  styleUrls: ['./view-role.component.css']
})
export class ViewRoleComponent implements OnInit {

  constructor() { }

  ngOnInit() {
    // $('#tblRole').DataTable({
    //   language: {
    //     search: "",
    //     searchPlaceholder: "Search..."
    //   },
    //   dom: 'Bfrtip',
    //   buttons: {
    //     buttons: [
    //       { extend: 'csv', text: 'CSV <i class="fa fa-download"></i>', className: 'btn-sm rounded btn-warning me-1' },
    //       { extend: 'excel', text: 'Excel <i class="fa fa-download"></i>', className: 'btn-sm rounded btn-success me-1' },
    //       { extend: 'pdf', text: 'PDF <i class="fa fa-download"></i>', className: 'btn-sm rounded btn-danger' }
    //     ]
    //   }
    // });
    // end view role
  }

}
