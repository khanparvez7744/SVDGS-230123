import { Component, OnInit } from '@angular/core';

import {schedule_flight_modal} from '../schedule-flight/schedule-flight-modal';
import {userService} from '../schedule-flight/schedule-flight-service';
import { interval } from 'rxjs';

@Component({
  selector: 'app-view-flight',
  templateUrl: './view-flight.component.html',
  styleUrls: ['./view-flight.component.css']
})
export class ViewFlightComponent implements OnInit {
  modal=schedule_flight_modal[1000];
  filteredModel=schedule_flight_modal[1000];
  // students: Observable<Student[]>;  
  modalArray:schedule_flight_modal[];
  flightNo :String='';
  savedFlight:boolean=false;


  constructor(public service :userService) {
    interval(8000).subscribe((x =>{
      this.refreshPage();
      }));

   }

  ngOnInit() {
    this.fetchData();
  }


  refreshPage(){
    this.savedFlight=false;
  }



  editList(editBy:String){
    this.filteredModel=[];

    this.modal.forEach((element:schedule_flight_modal )=> {
      if(element.flightstatus==editBy)
      this.filteredModel.push(element);
    });
    console.log("data has been filtered by",editBy);
  }

  fetchData(){
    this.service.getAll().subscribe((data :[])=>{
        console.log('data from mysql',data)
        this.modal=data;
        this.filteredModel=data;
      })
      this.filteredModel==this.modal;
      // this.modalArray=this.modal
  }

  edit(data:schedule_flight_modal){

    this.service.getActivateFlight(data).subscribe(data=>{
   }, 
  error => console.log(error));

  this.modal.forEach(element => {
    if(element.flightNo==data.flightNo)
    element.activate='true';
  });




    this.flightNo=data.flightNo;
    this.savedFlight=true;
    
    // this.modal.forEach(function(value){
    //  value.activate=true;
    // })

    // this.modal.forEach(function(value){
    //   console.log(value)
    //  })

    // window.location.reload();
  }


}
