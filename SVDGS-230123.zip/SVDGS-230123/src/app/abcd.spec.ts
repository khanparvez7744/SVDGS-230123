import { Abcd } from './abcd';

describe('Abcd', () => {
  it('should create an instance', () => {
    expect(new Abcd()).toBeTruthy();
  });
});
