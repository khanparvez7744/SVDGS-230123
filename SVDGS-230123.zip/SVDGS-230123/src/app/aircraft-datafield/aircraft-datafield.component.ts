import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-aircraft-datafield',
  templateUrl: './aircraft-datafield.component.html',
  styleUrls: ['./aircraft-datafield.component.css']
})
export class AircraftDatafieldComponent implements OnInit {

  constructor() { }

  ngOnInit() {
    jQuery(document).ready(function () {
      (<any>jQuery('#aircraftForm')).validate();
    });
  }

}
