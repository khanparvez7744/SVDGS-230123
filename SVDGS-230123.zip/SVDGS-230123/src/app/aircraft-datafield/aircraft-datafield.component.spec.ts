import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AircraftDatafieldComponent } from './aircraft-datafield.component';

describe('AircraftDatafieldComponent', () => {
  let component: AircraftDatafieldComponent;
  let fixture: ComponentFixture<AircraftDatafieldComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AircraftDatafieldComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AircraftDatafieldComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
