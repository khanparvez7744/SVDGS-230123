import { EmployeeDetailsComponent } from './employee-details/employee-details.component';
import { CreateEmployeeComponent } from './create-employee/create-employee.component';
import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { EmployeeListComponent } from './employee-list/employee-list.component';
import { DashboardComponent } from './dashboard/dashboard.component';
import { ScheduleFlightComponent } from './schedule-flight/schedule-flight.component';
import { ViewFlightComponent } from './view-flight/view-flight.component';
import { LoginComponent } from './login/login.component';
import { HomeComponent } from './home/home.component';
import { ReportsComponent } from './reports/reports.component';
import { AddRoleComponent } from './add-role/add-role.component';
import { ViewRoleComponent } from './view-role/view-role.component';
import { ViewUserComponent } from './view-user/view-user.component';
import { ManageUserComponent } from './manage-user/manage-user.component';
import { AddUserComponent } from './add-user/add-user.component';
import { ForgotPasswordComponent } from './forgot-password/forgot-password.component';
import { NotificationsComponent } from './notifications/notifications.component';
import { MappingComponent } from './mapping/mapping.component';
import { StandConfigurationComponent } from './stand-configuration/stand-configuration.component';
import { AircraftDatafieldComponent } from './aircraft-datafield/aircraft-datafield.component';
import { StandIdentificationFieldComponent } from './stand-identification-field/stand-identification-field.component';
import { TestModeComponent } from './test-mode/test-mode.component';
import { UpdateFlightComponent } from './update-flight/update-flight.component';
import { DataTablesModule } from "angular-datatables";

const routes: Routes = [
  { path: '', redirectTo: 'login', pathMatch: 'full' },
  { path: 'home', component: HomeComponent },
  { path: 'employees', component: EmployeeListComponent },
  { path: 'add', component: CreateEmployeeComponent },
  { path: 'dash', component: DashboardComponent },
  { path: 'schedule', component: ScheduleFlightComponent },
  { path: 'view', component: ViewFlightComponent },
  { path: 'login', component: LoginComponent },
  { path: 'report', component: ReportsComponent },
  { path: 'addRole', component: AddRoleComponent },
  { path: 'viewRole', component: ViewRoleComponent },
  { path: 'addUser', component: AddUserComponent },
  { path: 'manageUser', component: ManageUserComponent },
  { path: 'viewUser', component: ViewUserComponent }, 
  { path: 'forgotPass', component: ForgotPasswordComponent },
  { path: 'notification', component: NotificationsComponent },
  { path: 'mapping', component: MappingComponent },
  { path: 'svdgs', component: StandConfigurationComponent },
  { path: 'aircraftDatafield', component: AircraftDatafieldComponent },
  { path: 'standIdentificationField', component: StandIdentificationFieldComponent },
  { path: 'testMode', component: TestModeComponent },
  { path: 'updateFlight', component: UpdateFlightComponent }
];

@NgModule({
  imports: [RouterModule.forRoot(routes), DataTablesModule],
  exports: [RouterModule]
})
export class AppRoutingModule { }
