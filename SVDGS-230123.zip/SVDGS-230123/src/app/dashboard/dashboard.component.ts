import { Component, OnInit } from "@angular/core";
declare var window: any;

@Component({
  selector: "app-dashboard",
  templateUrl: "./dashboard.component.html",
  styleUrls: ["./dashboard.component.css"],
})
export class DashboardComponent implements OnInit {
  formModal: any;
  updformModal: any;

  constructor() {}

  ngOnInit() {
    this.formModal = new window.bootstrap.Modal(
      document.getElementById("schedModal")
    );
    this.updformModal = new window.bootstrap.Modal(
      document.getElementById("updatModal")
    );

    var ddlStatus = document.getElementsByClassName("ddlStatus");
    var iStatus;
    for (iStatus = 0; iStatus < ddlStatus.length; iStatus++) {
      ddlStatus[iStatus].addEventListener("click", function () {
        this.classList.toggle("activePlane");
        var ddContentStatus = this.nextElementSibling;
        if (ddContentStatus.style.display === "block") {
          ddContentStatus.style.display = "none";
        } else {
          ddContentStatus.style.display = "block";
        }
      });
    }

    var ddlRid = document.getElementsByClassName("ddlRid");
    var iRid;
    for (iRid = 0; iRid < ddlRid.length; iRid++) {
      ddlRid[iRid].addEventListener("click", function () {
        this.classList.toggle("activePlane");
        var ddContentRid = this.nextElementSibling;
        if (ddContentRid.style.display === "block") {
          ddContentRid.style.display = "none";
        } else {
          ddContentRid.style.display = "block";
        }
      });
    }

    var ddlCamera = document.getElementsByClassName("ddlCamera");
    var iCamera;
    for (iCamera = 0; iCamera < ddlCamera.length; iCamera++) {
      ddlCamera[iCamera].addEventListener("click", function () {
        this.classList.toggle("activePlane");
        var ddContentCamera = this.nextElementSibling;
        if (ddContentCamera.style.display === "block") {
          ddContentCamera.style.display = "none";
        } else {
          ddContentCamera.style.display = "block";
        }
      });
    }

    var ddlFlight = document.getElementsByClassName("ddlFlight");
    var iFlight;
    for (iFlight = 0; iFlight < ddlFlight.length; iFlight++) {
      ddlFlight[iFlight].addEventListener("click", function () {
        this.classList.toggle("activePlane");
        var ddContentFlight = this.nextElementSibling;
        if (ddContentFlight.style.display === "block") {
          ddContentFlight.style.display = "none";
        } else {
          ddContentFlight.style.display = "block";
        }
      });
    }
  }
  openFormModal() {
    this.formModal.show();
  }
  openUpdtModal() {
    this.updformModal.show();
  }
  saveSomeThing() {
    this.formModal.hide();
  }
  saveSomeThing2() {
    this.formModal.hide();
  }
  clsTogStatus = false;
  public toggleStatus() {
    this.clsTogStatus = !this.clsTogStatus;
  }
  clsTogRids = false;
  public toggleRids() {
    this.clsTogRids = !this.clsTogRids;
  }
  clsTogCmr = false;
  public toggleCmr() {
    this.clsTogCmr = !this.clsTogCmr;
  }
  clsTogFlt = false;
  public toggleFlt() {
    this.clsTogFlt = !this.clsTogFlt;
  }
  dnone = false;
  togSid = false;
  togcolsm9 = false;
  public togRightSid() {
    this.dnone = !this.dnone;
    this.togSid = !this.togSid;
    this.togcolsm9 = !this.togcolsm9;
  }
}
