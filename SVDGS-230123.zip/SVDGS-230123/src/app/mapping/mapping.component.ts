import { Component, OnInit } from '@angular/core';
import * as $ from 'jquery'
// import "datatables.net";
// import "datatables.net-dt";
// import "datatables.net-buttons-dt";

@Component({
  selector: 'app-mapping',
  templateUrl: './mapping.component.html',
  styleUrls: ['./mapping.component.css']
})
export class MappingComponent implements OnInit {

  constructor() { }

  ngOnInit() {
    jQuery(document).ready(function () {
      (<any>jQuery('#mappingForm')).validate();
    });
  }

}
