// start left section
var x_role,
    x_mng,
    x_fltOpe,
    x_confOpe,
    x_survOpe;
function mapingClk() {
    x_role.style.display = "none";
    x_mng.style.display = "none";
    x_fltOpe.style.display = "none";
    x_confOpe.style.display = "none";
    x_survOpe.style.display = "none";
}
function setingClk() {
    x_role.style.display = "none";
    x_mng.style.display = "none";
    x_fltOpe.style.display = "none";
    x_confOpe.style.display = "none";
    x_survOpe.style.display = "none";
}
function repotClk() {
    x_role.style.display = "none";
    x_mng.style.display = "none";
    x_fltOpe.style.display = "none";
    x_confOpe.style.display = "none";
    x_survOpe.style.display = "none";
}
function alertClk() {
    x_role.style.display = "none";
    x_mng.style.display = "none";
    x_fltOpe.style.display = "none";
    x_confOpe.style.display = "none";
    x_survOpe.style.display = "none";
}
function miscClk() {
    x_role.style.display = "none";
    x_mng.style.display = "none";
    x_fltOpe.style.display = "none";
    x_confOpe.style.display = "none";
    x_survOpe.style.display = "none";
}
function roleClk() {
    x_role = document.getElementById("roleEff");
    if (x_role.style.display === "none") {
        x_role.style.display = "block";
        x_mng.style.display = "none";
        x_fltOpe.style.display = "none";
        x_confOpe.style.display = "none";
        x_survOpe.style.display = "none";
    } else {
        x_role.style.display = "none";

    }
}
function mngClk() {
    x_mng = document.getElementById("mngEff")
    if (x_mng.style.display === "none") {
        x_mng.style.display = "block";
        x_role.style.display = "none";
        x_fltOpe.style.display = "none";
        x_confOpe.style.display = "none";
        x_survOpe.style.display = "none";
    } else {
        x_mng.style.display = "none";
    }
}
function fltOpeClk() {
    x_fltOpe = document.getElementById("fltOpeEff");
    if (x_fltOpe.style.display === "none") {
        x_fltOpe.style.display = "block";
        x_role.style.display = "none";
        x_mng.style.display = "none";
        x_confOpe.style.display = "none";
        x_survOpe.style.display = "none";
    } else {
        x_fltOpe.style.display = "none";
    }
}
function confOpeClk() {
    x_confOpe = document.getElementById("configEff");
    if (x_confOpe.style.display === "none") {
        x_confOpe.style.display = "block";
        x_role.style.display = "none";
        x_fltOpe.style.display = "none";
        x_mng.style.display = "none";
        x_survOpe.style.display = "none";
    } else {
        x_confOpe.style.display = "none";
    }
}
function survOpeClk() {
    x_survOpe = document.getElementById("survOpeEff");
    if (x_survOpe.style.display === "none") {
        x_survOpe.style.display = "block";
        x_role.style.display = "none";
        x_fltOpe.style.display = "none";
        x_mng.style.display = "none";
        x_confOpe.style.display = "none";
    } else {
        x_survOpe.style.display = "none";
    }
}
// end left section
// start schedule flight
function arrDepFun() {
    var x = document.getElementById('arrDepart').value;
    if (x == 'Arrival' || x == 'arrival') {
        document.getElementById('BaggageLabel').style.display = "block";
        document.getElementById('BaggageDiv').style.display = "block";
    }
    else {
        document.getElementById('BaggageLabel').style.display = "none";
        document.getElementById('BaggageDiv').style.display = "none";
    }
}
// end schedule flight
// start update flight
function arrDepFunUpd() {
    var x = document.getElementById('arrDepartUpd').value;
    if (x == 'Arrival' || x == 'arrival') {
        document.getElementById('BaggageLabelUpd').style.display = "block";
        document.getElementById('BaggageDivUpd').style.display = "block";
    }
    else {
        document.getElementById('BaggageLabelUpd').style.display = "none";
        document.getElementById('BaggageDivUpd').style.display = "none";
    }
}
// end update flight
window.addEventListener('load', () => {
    var scrnWidth = window.innerWidth;
    // start my profile button
    if ((scrnWidth > 768) && (scrnWidth < 1199)) {
        let changeVal = document.getElementById('changeVal');
        changeVal.classList.remove('float-end');
        changeVal.classList.add('text-center');
        changeVal.classList.add('mt-3');
        let nameVal = document.getElementById('nameVal');
        nameVal.classList.remove('float-start');
        nameVal.classList.add('text-center');
    }
    if ((scrnWidth > 576) && (scrnWidth <= 768)) {
        let changeVal = document.getElementById('changeVal');
        changeVal.classList.remove('float-end');
        changeVal.classList.add('text-center');
        let nameVal = document.getElementById('nameVal');
        nameVal.classList.remove('float-start');
        nameVal.classList.add('text-center');
    }
    // end my profile button
    // start left section
    if (scrnWidth <= 576) {
        let leftAdmin = document.getElementsByTagName('.leftAdmin li');
        leftAdmin.classList.remove('w-75 m-auto');
    }
    // end left section
});
// start sweet alert on del icon
function delMdl() {
    swal({
        title: "Are you sure?",
        text: "Once deleted, you will not be able to recover this record!",
        icon: "warning",
        buttons: true,
        dangerMode: true,
    })
        .then((willDelete) => {
            if (willDelete) {
                swal("Poof! Your record has been deleted!", {
                    icon: "success",
                });
            } else {
                swal("Your record is safe!");
            }
        });
}
// end sweet alert on del icon
// start number validation
function numberonly(evt) {
    evt = (evt) ? evt : window.event;
    var charCode = (evt.which) ? evt.which : evt.keyCode;
    if (charCode > 31 && (charCode < 48 || charCode > 57)) {
        return false;
    }
    return true;
}
// end number validation
// start captcha 
var captcha;
function geneCaptcha() {
    captcha = document.getElementById("codeCaptcha");
    var uniquechar = "";
    const randomchar =
        "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
    for (let i = 1; i < 5; i++) {
        uniquechar += randomchar.charAt(
            Math.random() * randomchar.length)
    }
    captcha.innerHTML = uniquechar;
}
function chnCaptcha() {
    const inpCaptcha = document
        .getElementById("txtCaptcha").value;
    if (inpCaptcha != captcha.innerHTML) {
        document.getElementById("btnLogin").disabled = true;
        // document.getElementById("captchaErr")
        //     .innerHTML = "Incorrent";
        alert("Captcha not matched")
    }
    else {
        document.getElementById("btnLogin").disabled = false;
        // document.getElementById("captchaErr")
        //     .innerHTML = "Correct";
    }
}
function btnLogin2() {
    const inpCaptcha = document
        .getElementById("txtCaptcha").value;
    if (inpCaptcha == captcha.innerHTML) {
        // document.getElementById("captchaErr")
        //     .innerHTML = "Correct";
    }
}
// end captcha
// start addRole 
function checkAllFlt(ele) {
    var chkFlt = document.getElementsByClassName('checkClassFlt');
    if (ele.checked) {
        for (var i = 0; i < chkFlt.length; i++) {
            if (chkFlt[i].type == 'checkbox') {
                chkFlt[i].checked = true;
            }
        }
    }
    else {
        for (var i = 0; i < chkFlt.length; i++) {
            if (chkFlt[i].type == 'checkbox') {
                chkFlt[i].checked = false;
            }
        }
    }
}
function checkAllUser(ele) {
    var chk = document.getElementsByClassName('checkClassMng');
    if (ele.checked) {
        for (var i = 0; i < chk.length; i++) {
            if (chk[i].type == 'checkbox') {
                chk[i].checked = true;
            }
        }
    }
    else {
        for (var i = 0; i < chk.length; i++) {
            if (chk[i].type == 'checkbox') {
                chk[i].checked = false;
            }
        }
    }
}

// end addRole 
// start chock report
// var minDate, maxDate;
// $.fn.dataTable.ext.search.push(
//     function (settings, data, dataIndex) {
//         var min = minDate.val();
//         var max = maxDate.val();
//         var date = new Date(data[4]);
//         if (
//             (min === null && max === null) ||
//             (min === null && date <= max) ||
//             (min <= date && max === null) ||
//             (min <= date && date <= max)
//         ) {
//             return true;
//         }
//         return false;
//     }
// );
// $(document).ready(function () {
//     minDate = new DateTime($('#min'), {
//         format: 'MMMM Do YYYY'
//     });
//     maxDate = new DateTime($('#max'), {
//         format: 'MMMM Do YYYY'
//     });
//     $('#min, #max').on('change', function () {
//         table.draw();
//     });
// });
// end chock report
// start flight report
// var minDateF, maxDateF;
// $.fn.dataTable.ext.search.push(
//     function (settings, data, dataIndex) {
//         var min = minDateF.val();
//         var max = maxDateF.val();
//         var date = new Date(data[4]);
//         if (
//             (min === null && max === null) ||
//             (min === null && date <= max) ||
//             (min <= date && max === null) ||
//             (min <= date && date <= max)
//         ) {
//             return true;
//         }
//         return false;
//     }
// );
// $(document).ready(function () {
//     minDateF = new DateTime($('#minF'), {
//         format: 'MMMM Do YYYY'
//     });
//     maxDateF = new DateTime($('#maxF'), {
//         format: 'MMMM Do YYYY'
//     });
//     $('#minF, #maxF').on('change', function () {
//         table2.draw();
//     });
// });
// end flight report
// start event report
// var minDateE, maxDateE;
// $.fn.dataTable.ext.search.push(
//     function (settings, data, dataIndex) {
//         var min = minDateE.val();
//         var max = maxDateE.val();
//         var date = new Date(data[4]);
//         if (
//             (min === null && max === null) ||
//             (min === null && date <= max) ||
//             (min <= date && max === null) ||
//             (min <= date && date <= max)
//         ) {
//             return true;
//         }
//         return false;
//     }
// );
// $(document).ready(function () {
//     minDateE = new DateTime($('#minE'), {
//         format: 'MMMM Do YYYY'
//     });
//     maxDateE = new DateTime($('#maxE'), {
//         format: 'MMMM Do YYYY'
//     });
//     $('#minE, #maxE').on('change', function () {
//         table3.draw();
//     });
// });
// end event report
//  start Aircraft Data Field
function addAircraftClk() {
    var air = document.getElementsByClassName("toglAircForm");
    Array.from(air).forEach((aircraft) => {
        if (aircraft.style.display === "none") {
            aircraft.style.display = "block";
        } else {
            aircraft.style.display = "none";
        }
    })
}
function delAircraftClk() {
    var col = document.getElementsByClassName("toglAircColm");
    Array.from(col).forEach((colum) => {
        if (colum.style.display === "none") {
            colum.style.display = "block";
        } else {
            colum.style.display = "none";
        }
    })
}
//  end Aircraft Data Field
// start dashbaord
function flightDashb() {
    var x = document.getElementById('textArival').value;
    if (x == 'Arrival' || x == 'arrival') {
        document.getElementById('lblBaggage').style.display = "block";
        document.getElementById('txtBaggage').style.display = "block";
    }
    else {
        document.getElementById('lblBaggage').style.display = "none";
        document.getElementById('txtBaggage').style.display = "none";
    }
}
function flightDashbUpd() { 
    var x = document.getElementById('textArivalUpd').value;
    if (x == 'Arrival' || x == 'arrival') {
        document.getElementById('lblBaggageUpd').style.display = "block";
        document.getElementById('txtBaggageUpd').style.display = "block";
    }
    else {
        document.getElementById('lblBaggageUpd').style.display = "none";
        document.getElementById('txtBaggageUpd').style.display = "none";
    }
}
// end dashbaord
